# 화면 실시간 번역기 (Android)

## APK 만드는 방법
### A) Android Studio
1. Android Studio → Open → 이 폴더 선택 → Gradle Sync 완료까지 대기
2. 메뉴 Build → Build APK(s)
3. app/build/outputs/apk/debug/app-debug.apk 를 폰으로 옮겨 설치

### B) 설치 없이 GitHub로 빌드
1. 이 폴더 내용을 GitHub 새 저장소에 올리기 (.github 폴더 포함)
2. 저장소의 Actions 탭 → Build APK 실행 완료 후 Artifacts의 app-debug 다운로드

## 사용
- 앱 실행 → 원문 언어 선택 → 시작 → 권한(다른 앱 위에 표시, 화면 녹화) 허용
- 번역창 바깥 화면 글자를 1초 간격으로 읽어 한국어로 표시
- 첫 실행 때 번역 모델(약 30MB) 다운로드를 위해 인터넷 필요, 이후엔 오프라인 동작
