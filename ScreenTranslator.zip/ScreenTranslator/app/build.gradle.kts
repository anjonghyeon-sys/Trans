plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.screentranslator"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.screentranslator"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")          // 영어(라틴)
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1") // 일본어
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")  // 중국어
    implementation("com.google.mlkit:translate:17.0.3")                 // 온디바이스 번역
}
