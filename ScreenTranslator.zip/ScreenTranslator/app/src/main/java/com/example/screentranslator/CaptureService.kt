package com.example.screentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.max

class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var worker: HandlerThread
    private lateinit var bg: Handler
    private lateinit var wm: WindowManager

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var recognizer: TextRecognizer
    private lateinit var translator: Translator

    private var sw = 0
    private var sh = 0

    private lateinit var panel: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var body: TextView
    private lateinit var status: TextView
    private lateinit var pauseBtn: TextView

    @Volatile private var panelRect = Rect()
    @Volatile private var running = true
    @Volatile private var busy = false
    @Volatile private var ready = false

    private var showOrig = false
    private var fontSp = 16f
    private var orig = ""
    private var trans = ""
    private var lastKey = ""
    private var prev: IntArray? = null
    private val cache = HashMap<String, String>()

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startFg()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val lang = intent.getStringExtra("lang") ?: "en"

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        worker = HandlerThread("cap").also { it.start() }
        bg = Handler(worker.looper)

        readScreen()
        buildPanel()
        initEngines(lang)
        initCapture(code, data)
        bg.postDelayed(tick, 1000)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "화면 번역", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("화면 번역 실행 중")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun readScreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width(); sh = b.height()
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels; sh = m.heightPixels
        }
    }

    private fun initEngines(lang: String) {
        val (src, rec) = when (lang) {
            "ja" -> TranslateLanguage.JAPANESE to TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            "zh" -> TranslateLanguage.CHINESE to TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            else -> TranslateLanguage.ENGLISH to TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        recognizer = rec
        translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(TranslateLanguage.KOREAN).build()
        )
        setStatus("번역 모델 준비 중…")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { ready = true; setStatus("") }
            .addOnFailureListener { setStatus("모델 다운로드 실패 - 인터넷 확인") }
    }

    private fun initCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "cap", sw, sh, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    // ---------- 번역창 ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 15f
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { onClick() }
    }

    private fun updateRect() { panelRect = Rect(lp.x, lp.y, lp.x + lp.width, lp.y + lp.height) }

    private fun setStatus(s: String) { main.post { status.text = s } }

    private fun render() { body.text = if (showOrig) orig else trans }

    private fun buildPanel() {
        lp = WindowManager.LayoutParams(
            (sw * 0.92).toInt(), (sh * 0.3).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (sw * 0.04).toInt()
            y = (sh * 0.62).toInt()
        }

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#37474F"))
        }
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B0BEC5"))
            textSize = 12f
            setPadding(dp(10), 0, 0, 0)
            text = "번역"
        }
        header.addView(status, LinearLayout.LayoutParams(0, WRAP, 1f))
        pauseBtn = tv("⏸") { running = !running; pauseBtn.text = if (running) "⏸" else "▶" }
        header.addView(pauseBtn)
        header.addView(tv("A-") { fontSp = max(10f, fontSp - 2f); body.textSize = fontSp })
        header.addView(tv("A+") { fontSp = minOf(40f, fontSp + 2f); body.textSize = fontSp })
        header.addView(tv("원문") { showOrig = !showOrig; render() })
        header.addView(tv("✕") { stopSelf() })
        panel.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var rx = 0f; var ry = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; rx = e.rawX; ry = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - rx).toInt()
                        lp.y = sy + (e.rawY - ry).toInt()
                        wm.updateViewLayout(panel, lp)
                        updateRect()
                    }
                }
                return true
            }
        })

        body = TextView(this).apply {
            setTextColor(Color.BLACK)
            textSize = fontSp
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        panel.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val handle = TextView(this).apply {
            text = "◢"
            setTextColor(Color.GRAY)
            textSize = 20f
            gravity = Gravity.END
            setPadding(dp(8), 0, dp(12), dp(4))
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var w0 = 0; var h0 = 0; var rx = 0f; var ry = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { w0 = lp.width; h0 = lp.height; rx = e.rawX; ry = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.width = max(dp(200), w0 + (e.rawX - rx).toInt())
                        lp.height = max(dp(120), h0 + (e.rawY - ry).toInt())
                        wm.updateViewLayout(panel, lp)
                        updateRect()
                    }
                }
                return true
            }
        })
        panel.addView(handle, LinearLayout.LayoutParams(MATCH, WRAP))

        wm.addView(panel, lp)
        updateRect()
    }

    // ---------- 캡처 / OCR / 번역 ----------
    private val tick = object : Runnable {
        override fun run() {
            try { if (running && ready && !busy) grab() } catch (_: Exception) {}
            bg.postDelayed(this, 1000)
        }
    }

    private fun grab() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp = try {
            val pl = img.planes[0]
            val rowPx = pl.rowStride / pl.pixelStride
            val full = Bitmap.createBitmap(rowPx, sh, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(pl.buffer)
            if (rowPx != sw) Bitmap.createBitmap(full, 0, 0, sw, sh).also { full.recycle() } else full
        } finally {
            img.close()
        }
        if (!changed(bmp)) { bmp.recycle(); return }
        busy = true
        main.post { process(bmp) }
    }

    /** 화면이 바뀌었는지 대충 비교 (번역창 영역은 제외) */
    private fun changed(bmp: Bitmap): Boolean {
        val w = 108
        val h = 216
        val s = Bitmap.createScaledBitmap(bmp, w, h, false)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        s.recycle()
        val p = prev
        prev = px
        if (p == null) return true
        val pr = panelRect
        var cnt = 0
        for (r in 0 until h) {
            val cy = (r + 0.5f) * sh / h
            if (cy >= pr.top && cy <= pr.bottom) continue
            for (c in 0 until w) {
                val a = px[r * w + c]
                val b = p[r * w + c]
                val d = abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
                    abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
                    abs((a and 255) - (b and 255))
                if (d > 60) cnt++
            }
        }
        return cnt > 10
    }

    private fun mostlyKorean(s: String): Boolean {
        val k = s.count { it in '가'..'힣' }
        return k > 0 && k.toFloat() / s.length > 0.3f
    }

    private fun process(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                val pr = panelRect
                val blocks = t.textBlocks
                    .filter { b -> b.boundingBox?.let { !pr.contains(it.centerX(), it.centerY()) } ?: false }
                    .sortedBy { it.boundingBox!!.top }
                    .map { it.text.replace("\n", " ").trim() }
                    .filter { it.length > 1 && !mostlyKorean(it) }
                bmp.recycle()
                handleBlocks(blocks)
            }
            .addOnFailureListener { bmp.recycle(); busy = false }
    }

    private fun handleBlocks(blocks: List<String>) {
        val key = blocks.joinToString("\n")
        if (key == lastKey) { busy = false; return }
        lastKey = key
        if (blocks.isEmpty()) { orig = ""; trans = ""; render(); busy = false; return }
        if (cache.size > 500) cache.clear()

        val res = arrayOfNulls<String>(blocks.size)
        var left = blocks.size
        fun done() {
            if (--left == 0) {
                orig = blocks.joinToString("\n\n")
                trans = res.joinToString("\n\n") { it ?: "" }
                render()
                busy = false
            }
        }
        blocks.forEachIndexed { i, s ->
            val c = cache[s]
            if (c != null) {
                res[i] = c
                done()
            } else {
                translator.translate(s)
                    .addOnSuccessListener { r -> cache[s] = r; res[i] = r }
                    .addOnFailureListener { res[i] = s }
                    .addOnCompleteListener { done() }
            }
        }
    }

    override fun onDestroy() {
        running = false
        if (::bg.isInitialized) bg.removeCallbacksAndMessages(null)
        if (::worker.isInitialized) worker.quitSafely()
        if (::panel.isInitialized) try { wm.removeView(panel) } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        if (::recognizer.isInitialized) recognizer.close()
        if (::translator.isInitialized) translator.close()
        super.onDestroy()
    }
}
