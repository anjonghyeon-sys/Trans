package com.example.screentranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqProj = 1
    private val reqOverlay = 2
    private val langs = listOf("영어" to "en", "일본어" to "ja", "중국어" to "zh")
    private var langIdx = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "화면 실시간 번역기"; textSize = 22f })
        root.addView(TextView(this).apply {
            text = "원문 언어를 고르고 시작을 누르세요.\n" +
                "번역창은 헤더를 드래그해서 옮기고, 오른쪽 아래 ◢로 크기를 조절해요.\n" +
                "번역창 바깥 화면의 글자를 읽어서 한국어로 보여줘요."
            setPadding(0, pad / 2, 0, pad / 2)
        })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { langIdx = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp)
        root.addView(Button(this).apply { text = "시작"; setOnClickListener { start() } })
        root.addView(Button(this).apply {
            text = "중지"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        })
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'다른 앱 위에 표시' 권한을 허용해 주세요", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                reqOverlay
            )
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProj)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == reqOverlay && Settings.canDrawOverlays(this)) start()
        if (req == reqProj && res == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", res)
                .putExtra("data", data)
                .putExtra("lang", langs[langIdx].second)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
